This might prompt with a popup from windows defender. This is cuz it is trying to fix you wifi drivers
CODE IS PUBLIC :https://github.com/thatwififixguy/wififix
Password: patch
